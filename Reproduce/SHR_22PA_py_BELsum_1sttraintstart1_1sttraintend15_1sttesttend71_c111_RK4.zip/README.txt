To reproduce the results of https://sites.uclouvain.be/absil/2020.05, run the *.py file with Python 3.
Tested with anaconda 2019.10.
- PA Absil, 2020-07-19


