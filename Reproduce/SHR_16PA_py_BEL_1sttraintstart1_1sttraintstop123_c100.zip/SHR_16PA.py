# Execute this file with python 3.
# Tested with anaconda version 2019.10.

# Code written by PA Absil and Ousmane Diao. There is NO WARRANTY of prediction accuracy.

# SHR_01PA.m - Started by PA on Sun 05 Jul 2020
# SHR_02PA.m - Started by PA on Sun 05 Jul 2020
#    Yields a remarkably good fit.
# SHR_03PA.m - Started by PA on Sun 05 Jul 2020
#    Version sent to Ousmane. Forked to Python version by Ousmane
# SHR_03PA_04OD.py
#    Version obtained from Ousmane on 2020-07-15
# SHR_03PA_05PA.py - Started by PA on Thu 16 Jul 2020
#    I plan to stay with Python from now on (instead of Matlab).
#    This version works well, both on the Linux command line and in Spyder. Figure 4 is particularly remarkable.
# SHR_03PA_06PA.py - Started by PA on Thu 16 Jul 2020
#    Clean up the code. Make it more compact. Use arrays of floats whenever possible. Define functions to avoid code repetition. From about 460 lines in SHR_03PA_04OD.py, we are down to about 360 lines (and the number of empty lines and comment lines has increased).
# SHR_03PA_07PA.py - Started by PA on Thu 16 Jul 2020
#     Reorder arguments of phi* functions more intuitively. Encapsulate various estimation tasks in functions estimate_* (as a preparation for loops on train periods). 
# SHR_03PA_08PA.py - Started by PA on Fri 17 Jul 2020
#     Loops on train periods.
# SHR_03PA_09PA.py - Started by PA on Fri 17 Jul 2020
#     Improve plots. Enable test_t_end.
# SHR_03PA_10PA.py - Started by PA on Sun 19 Jul 2020
#     Handle French data.
#     Plot E, L, EH. Set the bottom value of some plots to 0.
# SHR_15PA.py - Started by PA on Sun 19 Jul 2020
#     The Python version is now comparable to the Matlab version, hence this jump in the numbering.
# SHR_16PA.py - Started by PA on Mon 20 Jul 2020
#     Continue experimenting.

# Imports:

# In[80]:
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#plt.rc('xtick', labelsize='x-small')
#plt.rc('ytick', labelsize='x-small')
#plt.rcParams['style'] = "sci"  # PATODO
#plt.rcParams['scilimits'] = (0,0)

#from scipy.integrate import odeint
import math 
#from mpl_toolkits.mplot3d import Axes3D
#from math import hypot
from scipy import optimize
#from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt
#To change repertory
import os
#os.chdir ('C:\\Users\\odiao\\Desktop\\Model Covid19')
#os.getcwd ()
import copy
from datetime import datetime   # useful for date ranges in plots

# Switches:

sw_dataset = 'BEL'  # !! Default: 'BEL' # Currently 'BEL' and 'FRA' are available.
show_totinout = 0  # Default: 0 # If 1, shows plots of total, in and out and check their discrepancy.
save_figures = 1  # If 1, some figures will be saved in pdf format.

show_H = 1
show_S_bar = 0
show_beta_bar = 0
show_gamma = 0

# ***********************************************************************************
# Load data Belgium
# *******

if sw_dataset == 'BEL':   
    # The data comes from https://epistat.sciensano.be/Data/COVID19BE_HOSP.csv.
    # This link was provided on 22 June 2020 by Alexey Medvedev on the "Re R0 estimation" channel of the O365G-covidata team on MS-Teams.
    # The link can be reached from https://epistat.wiv-isp.be/covid/
    # Some explanations can be found at https://epistat.sciensano.be/COVID19BE_codebook.pdf

    # In[81]:
    data_raw = pd.read_csv('Data/Belgium/COVID19BE_HOSP_2020-07-16.csv')
    #fields = ['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']
    data = data_raw[['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']]  # exclude "PROVINCE" column
    data = data.groupby('DATE', as_index=False).sum()  # sum over provinces

    # Extract relevant data and recompute new_out:
    # Source: Some variable names taken from https://rpubs.com/JMBodart/Covid19-hosp-be
    data_length = np.size(data,0)
    data_num = data.iloc[:,1:].to_numpy(dtype=float)  # extract all rows and 2nd-last rows (recall that Python uses 0-based indexing) and turn it into a numpy array of flats. The "float" type is crucial due to the use of np.nan below. (Setting an integer to np.nan does not do what it is should do.)

    #dates = data['DATE'])
    dates_raw = copy.deepcopy(data['DATE'])
    dates = [None] * data_length
    for i in range(0,data_length):
        dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

    col_total_in = 1
    col_new_in = 5
    col_new_out = 6
    total_in = data_num[:,col_total_in]
    new_in = data_num[:,col_new_in]
    new_out_raw = data_num[:,col_new_out] # there will be a non-raw due to the "Problem" mentioned below.
    new_delta = new_in - new_out_raw
    cum_new_delta = np.cumsum(new_delta)
    total_in_chg = np.hstack(([0],np.diff(total_in))) #difference between x[i+1]-x[i]
    # Problem: new_delta and total_in_chg are different, though they are sometimes close. 
    # Cum_new_delta does not go back to something close to zero, whereas it should. Hence I should not trust it.
    # I'm going to trust total_in and new_in. I deduce new_out_fixed by:
    new_out = new_in - total_in_chg   # fixed new_out
    data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns


    # Show Belgian data in figures:

    # In[84]:
    if show_totinout:
        plt.figure(figsize=(10,8))
        plt.subplot(2,2,1)
        plt.plot(dates, total_in)
        plt.plot(dates,cum_new_delta)
        plt.xlabel("Dates")
        plt.ylabel("Values")
        plt.legend(("total_in","cum_new_delta"))
        #plt.ylim([0,1000])

        plt.subplot(2,2,2)
        plt.plot(dates,new_delta)
        plt.plot(dates,total_in_chg)
        plt.xlabel("Dates")
        plt.ylabel("Values")
        plt.legend(("new_delta","total_in_chg"))

        plt.subplot(2,2,3)
        plt.plot(dates,new_out_raw)
        plt.plot(dates,new_out)
        plt.legend(("new_out_raw","new_out"))

        plt.show(block=False)
    # end if show_totinout

# ***********************************************************************************
# Load data France
# *******

elif sw_dataset == 'FRA':  # if sw_datset is 'FRA'

    # The data comes from https://www.data.gouv.fr/en/datasets/donnees-hospitalieres-relatives-a-lepidemie-de-covid-19/, see donnees-hospitalieres-covid19-2020-07-10-19h00.csv

    data_raw = pd.read_csv('Data/France/donnees-hospitalieres-covid19-2020-07-10-19h00_corrected.csv')  # some dates were not in the correct format, hence the "corrected" versino of the csv file
    #fields = ['dep','sexe','jour','hosp','rea','rad','dc']
    data = data_raw[['jour','hosp','rea','rad','dc']]  # exclude useless columns
    data = data.groupby('jour', as_index=False).sum()  # sum over identical dates
    
    # Extract relevant data and recompute new_in:
    data_length = np.size(data,0)
    data_num = data.iloc[:,1:].to_numpy(dtype=float)  # extract all rows and 2nd-last rows (recall that Python uses 0-based indexing) and turn it into a numpy array of flats. The "float" type is crucial due to the use of np.nan below. (Setting an integer to np.nan does not do what it is should do.)

    #dates = data['DATE'])
    dates_raw = copy.deepcopy(data['jour'])
    dates = [None] * data_length
    for i in range(0,data_length):
        dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

    col_total_in = 0
    col_new_in = np.nan   # no column for new_in in French data
    col_new_out = np.nan  # to get new_out we have to sum 'rad' and 'dc'
    total_in = data_num[:,col_total_in]
    new_out = np.hstack(([0],np.diff(data_num[:,2] + data_num[:,3])))
    total_in_chg = np.hstack(([0],np.diff(total_in)))
    new_in = new_out + total_in_chg
    data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns

# end if sw_dataset

# ***********************************************************************************
# Select train periods
# *******

# # One small train period around peak:
# train_t_start_vals = np.array([18]);    # For Belgium, dates[17] is 2020-04-01
# train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
# test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int); 

# # Two small train periods:
# train_t_start_vals = np.array([10,60]);    # For Belgium, dates[17] is 2020-04-01
# train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
# test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);

# # Sliding train and test windows:
# train_t_start_vals = np.arange(1,len(total_in)-28,7)  
# train_t_end_vals = train_t_start_vals + 14
# test_t_end_vals = train_t_end_vals + 14 

# # Sliding train window: *keep* - also for FRA
# train_t_start_vals = np.arange(1,len(total_in)-28,7) 
# train_t_end_vals = train_t_start_vals + 14
# test_t_end_vals = len(total_in) * np.ones(np.shape(train_t_start_vals),dtype=int);


# One large train:  *keep*-with c_E=c_L=0, only show_H
train_t_start_vals = np.array([1]);
train_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);
test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int); 

# # A few small trains:  *keep*-only show_H show_S
# #train_t_start_vals = np.array([10,12,14,16,18,20,22])
# train_t_start_vals = np.arange(16,22,2)
# train_t_end_vals = (32) * np.ones(np.shape(train_t_start_vals),dtype=int)
# #train_t_end_vals = train_t_start_vals + 14
# test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int)

# # This one gives a MAPE_test of 7.9% for Belgium
# train_t_start_vals = np.array([18])
# train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
# test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int); 


# ***********************************************************************************
# Preparation
# *******

# Make sure that we are working with arrays of integers:
train_t_start_vals = train_t_start_vals.astype(int)
train_t_end_vals = train_t_end_vals.astype(int)
test_t_end_vals = test_t_end_vals.astype(int)

# Weights of the terms of the cost function:
c_H, c_E, c_L = 1, 0, 0 # !! Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
c_HEL = [c_H,c_E,c_L]

# Part of file name of figures:
fig_name_root = 'Figures/' + os.path.splitext(os.path.basename(__file__))[0] + '_py_' + sw_dataset + '_1sttraintstart' + str(train_t_start_vals[0]) + '_1sttraintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L)


# ***********************************************************************************
# Show available data
# *******

plt.figure(figsize=(10,8))
#plt.subplot(2,2,1)
plt.plot(dates, total_in/np.max(total_in), "-", color='gray', label="Total_in norm\'d")
plt.plot(dates, new_out/np.max(np.hstack((new_in,new_out))), 'm--', label="new_in norm\'d")
plt.plot(dates, new_in/np.max(np.hstack((new_in,new_out))), 'b-.', label="new_out norm\'d")
plt.plot(dates, new_in * total_in / np.max(new_in * total_in), ':', color='tab:purple', label="total_in * new_in norm\'d")
plt.xlabel("Dates")
plt.ylabel("Values")
plt.legend()

plt.show(block=False)



# In[87]:
#***********************************************************************************
# Define gamma estimation function
# *******
# Model for gamma: new_out = gamma * total_in

def estimate_gamma(tspan_train,data_totinout_train):

    train_t_start = tspan_train[0]
    train_t_end = tspan_train[1]
    total_in_train = data_totinout_train[:,0]
    new_out_train = data_totinout_train[:,2]

    # Estimator by ratio of means:
    #gamma_hat_RM = sum(new_out_train[0:train_t_end])/sum(total_in_train[0:train_t_end]) # This version uses all the non-test data.
    gamma_hat_RM = sum(new_out_train[train_t_start:train_t_end])/sum(total_in_train[train_t_start:train_t_end])  # This version uses only the "train" period.

    # Estimator by least squares:
    #gamma_hat_LS = total_in_train[0:train_t_end]\new_out_train[0:train_t_end]
    gamma_hat_LS = np.linalg.lstsq(np.c_[total_in_train[0:train_t_end]],new_out_train[0:train_t_end], rcond=None)[0]

    # Estimator by ratio of means on all data (test and train):  not legitimate
    #gamma_hat_all_RM = sum(new_out_train)/sum(total_in_train);

    # I observe that the RM and LS estimates are quite close. Let's keep:
    gamma = gamma_hat_RM
    #gamma = gamma_hat_all_RM;  % not legitimate

    return gamma
# end def estimate_gamma

# In[90]:
# ***********************************************************************************
# Define several functions: the SH simulation function; the general cost function on which the various parameter estimations will be based; a function that returns statistics; a function that draw plots of simulation results
# *******

# Define the simulation function of the SH model:
def simu(beta_bar,gamma,S_bar_init,H_init,tspan):
    simu_t_start = tspan[0]
    simu_t_end = tspan[1]
    S_bar = np.full((simu_t_end,1), np.nan)  # set storage Z = np.full(X.shape, np.nan)
    H = np.full(simu_t_end, np.nan)  # set storage
    E = np.full(simu_t_end, np.nan)  # set storage
    L = np.full(simu_t_end, np.nan)  # set storage
    S_bar[simu_t_start] = S_bar_init
    H[simu_t_start] = H_init

    for t in np.arange(simu_t_start,simu_t_end-1):
        S_bar[t+1] = S_bar[t] - beta_bar * S_bar[t] * H[t]
        H[t+1] = H[t] + beta_bar * S_bar[t] * H[t] - gamma * H[t]
        E[t+1] = beta_bar * S_bar[t] * H[t]
        L[t+1] = gamma * H[t]
    return (S_bar,H,E,L)
# end def simu

# Define the loss function in terms of all the possible decision variables, i.e., beta_bar,gamma,S_bar_init,H_init :
def phi_basic(beta_bar,gamma,S_bar_init,H_init,tspan_train,data_totinout_train,c_HEL):
    # Extract variables from input:
    c_H, c_E, c_L = c_HEL  #coefficients of the terms of the cost function. Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
    train_t_start, train_t_end = tspan_train
    _, H, E, L = simu(beta_bar,gamma,S_bar_init,H_init,tspan=tspan_train)  # "_" because S_bar is not involved in the cost
    # Compute the cost (discrepancy between observed and simulated):
    cost = c_H * (np.linalg.norm(H[train_t_start:train_t_end]-data_totinout_train[train_t_start:train_t_end,0]))**2 + c_E * (np.linalg.norm(E[train_t_start+1:train_t_end]-data_totinout_train[train_t_start+1:train_t_end,1]))**2 + c_L * (np.linalg.norm(L[train_t_start+1:train_t_end]-data_totinout_train[train_t_start+1:train_t_end,2]))**2
    return cost

# Define functions for statistics:
def MAPE(y_true, y_pred):  # MAPE is "Mean Absolute Percentage Error"
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100
def make_stats(beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
    S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
    RMSE_train = np.linalg.norm(H[train_t_start:train_t_end] - total_in[train_t_start:train_t_end]) / math.sqrt(train_t_end-train_t_start)
    RMSE_test = np.linalg.norm(H[train_t_end+1:] - total_in[train_t_end+1:]) / math.sqrt(data_length-train_t_end)
    MAPE_train=MAPE(np.array(total_in[train_t_start:train_t_end]), np.array(H[train_t_start:train_t_end]))
    MAPE_test=MAPE(np.array(total_in[train_t_end:]), np.array(H[train_t_end:]))
    return {'RMSE_train': RMSE_train, 'RMSE_test': RMSE_test, 'MAPE_train': MAPE_train, 'MAPE_test': MAPE_test}

# Define function for plots:
def make_plots(beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
    S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
    nb_subplots = show_H + show_S_bar + show_beta_bar + show_gamma
    if nb_subplots == 4:
        nb_subplot_rows = 2
        nb_subplot_cols = 2
        plt.rc('xtick', labelsize='x-small')
        plt.rc('ytick', labelsize='x-small')
    else:
        nb_subplot_rows = 1
        nb_subplot_cols = nb_subplots 
    cnt_subplot = 0
    nb_xticks = 4
    dates_ticks = [None] * nb_xticks
    dates_ticks_ind = np.linspace(0,len(total_in)-1,nb_xticks,dtype=int)
    for i in range(0,nb_xticks):
        dates_ticks[i] = dates[dates_ticks_ind[i]]
    
    if show_H:
        cnt_subplot = cnt_subplot + 1
        plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
    
        if period_cnt == 0:   # assign plot labels
            plt.plot(dates,total_in, "-", color='gray', label="Total_in", linewidth=1)
            plt.plot(dates[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
            plt.plot(dates[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.', label="H_pred")
            plt.legend()
        else:
            plt.plot(dates[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--')
            plt.plot(dates[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.')
        plt.xticks(dates_ticks)
        plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
        if period_cnt == len(train_t_start_vals)-1:
            plt.ylim(bottom=0)

    if show_S_bar:
        cnt_subplot = cnt_subplot + 1
        plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
        if period_cnt == 0:   # assign plot labels
            plt.plot(dates[0:train_t_end],S_bar[0:train_t_end],'b--', label="S_bar_train")
            plt.plot(dates[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.', label="S_bar_pred")

            plt.legend()
        else:
            plt.plot(dates[train_t_start:train_t_end],S_bar[train_t_start:train_t_end],'b--')
            plt.plot(dates[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.')
        plt.xticks(dates_ticks)
        plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
        if period_cnt == len(train_t_start_vals)-1:
            plt.ylim(bottom=0)

    if show_beta_bar:
        cnt_subplot = cnt_subplot + 1
        plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
        if period_cnt == 0:   # assign plot labels
            plt.plot(dates[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--', label="beta_bar_train")
            plt.plot(dates[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.', label="beta_bar_pred")
            plt.legend()
        else:
            plt.plot(dates[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--')
            plt.plot(dates[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.')
        plt.xticks(dates_ticks)
        plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
        if period_cnt == len(train_t_start_vals)-1:
            plt.ylim(bottom=0)

    if show_gamma:
        cnt_subplot = cnt_subplot + 1
        plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
        if period_cnt == 0:   # assign plot labels
            plt.plot(dates[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--', label="gamma_train")
            plt.plot(dates[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.', label="gamma_pred")
            plt.legend()
        else:
            plt.plot(dates[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--')
            plt.plot(dates[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.')
        plt.xticks(dates_ticks)
        plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
        if period_cnt == len(train_t_start_vals)-1:
            plt.ylim(bottom=0)
    return
# end def make_plots

# In[92]:
# ***********************************************************************************
# Optimization wrt beta_bar and S_bar_init
# *******

# Define the loss function where "x" contains the decision variables of interest in this section of the code, namely x := [beta_bar,S_bar_init]:
def phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL):
    return phi_basic(x[0],gamma,x[1],H_init,tspan_train,data_totinout_train,c_HEL)

# Extract train variables in order to do a first plot of the cost function:
train_t_start = train_t_start_vals[0]
train_t_end = train_t_end_vals[0]
test_t_end = test_t_end_vals[0]
tspan_train = [train_t_start,train_t_end]
data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.

# Define anonymous function for used in optimization solver:
H_init = data_totinout_train[tspan_train[0],0]
gamma = estimate_gamma(tspan_train,data_totinout_train)  # estimate gamma
fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above

# First plot of cost function, to get an idea of an init point for the optimization solver:
beta_bar_vals = np.linspace(0,2e-5,100)  #beta_bar_vals = np.linspace(8e-6,12e-6,10)
S_bar_init_vals = np.linspace(0,2e4,100)   #S_bar_init_vals = np.linspace(8e3,10e3,10)
X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
for i in np.arange(0,np.size(X,0)):
     for j in np.arange(0,np.size(X,1)):
            #print(i,j)
            #[X[i,j],Y[i,j]]
            Z[i,j] = fun([X[i,j],Y[i,j]]) 
plt.figure()  # PATODO
plt.contourf(X, Y, Z)
plt.colorbar()
#plt.locator_params(axis='x', nbins=3)  # PATODO
#plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
plt.show(block=False)

# Define function for the estimation of beta_bar and S_bar_init:
def estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL):  # estimation method with beta_bar and S_bar_init as optimization variables
    # Estimate gamma:
    gamma = estimate_gamma(tspan_train,data_totinout_train)
    fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above
    x_guess = [1e-5,1e4]  # sugg: [2e-5,1e4]
    x_opt = optimize.fmin(fun,x_guess)  # call the optimization solver
    beta_bar_opt = x_opt[0]
    S_bar_init_opt = x_opt[1]
    fun_opt = fun([beta_bar_opt,S_bar_init_opt])  # value of the minimum, useful for plot
    return (beta_bar_opt, S_bar_init_opt, gamma, fun_opt, fun)


plt.figure(figsize=(10,8))
statss = [None] * len(train_t_start_vals)  # storage for stats

# [[[ Start loop on train periods:
for period_cnt in range(0, len(train_t_start_vals)):

    # Extract train variables for period period_cnt:
    train_t_start = train_t_start_vals[period_cnt]
    train_t_end = train_t_end_vals[period_cnt]
    test_t_end = test_t_end_vals[period_cnt]
    tspan_train = [train_t_start,train_t_end]
    # The test data is defined to be all the data that occurs from train_t_end.
    # Replace test data by NaN in *_train variables.
    data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
    data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
    # ! Make sure to use only these *_train variables in the train phase.
    H_init = data_totinout_train[tspan_train[0],0]
    
    # Estimate beta_bar and S_bar_init by optimizing the cost function:
    beta_bar_opt, S_bar_init_opt, gamma, fun_opt, fun = estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL)

    # In[94]:
    # Compute statistics:
    stats = make_stats(beta_bar_opt, gamma, S_bar_init_opt, H_init, tspan_train, dates, data_totinout)
    statss[period_cnt] = stats

    # Plot true and simulated H, and simulated S_bar:
    make_plots(beta_bar_opt,gamma,S_bar_init_opt,H_init,tspan_train,dates,data_totinout)  
    #end if period_cnt

# ]]] end loop on train periods
#plt.title("Optimized wrt beta_bar and S_bar_init")
plt.show(block=False)
if save_figures: plt.savefig(fig_name_root + '_2D.pdf', format='pdf', bbox_inches='tight')

# In[93]:
# Plot the cost function around the found minimizer:
beta_bar_vals = np.linspace(0,beta_bar_opt*2,100)
S_bar_init_vals = np.linspace(0,S_bar_init_opt*2,100)
X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
for i in np.arange(0,np.size(X,0)):
     for j in np.arange(0,np.size(X,1)):
        Z[i,j] = math.log10(fun([X[i,j],Y[i,j]])-fun_opt*0.99)
plt.figure(figsize=(10,8))
plt.contourf(X, Y, Z)
plt.colorbar()
plt.title('log10(fun - fun\_opt*.99))')
#plt.locator_params(axis='x', nbins=3)  # PATODO
#plt.ticklabel_format(axis="x", style="sci", scilimits=(0,0))
plt.ticklabel_format(style="sci", scilimits=(0,0))
plt.show(block=False)
fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_contour.pdf'
if save_figures: plt.savefig(fig_name_root + '_contour.pdf', format='pdf', bbox_inches='tight')


# ***********************************************************************************
# Optimization wrt beta_bar, S_bar_init, and gamma
# *******
    
# In[ ]:
def phi_gamma(x,H_init,tspan_train,data_totinout_train,c_HEL):  #x := [beta_bar,S_bar_init,gamma]
    return phi_basic(x[0],x[2],x[1],H_init,tspan_train,data_totinout_train,c_HEL)

# Define function for the estimation of beta_bar, S_bar_init, and gamma:
def estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL):
    fun_gamma = lambda x:phi_gamma(x,H_init,tspan_train,data_totinout_train,c_HEL)
    beta_bar_guess, S_bar_init_guess, gamma_guess, _, _ = estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL)
    x_guess_gamma = [beta_bar_guess,S_bar_init_guess,gamma_guess]       #[x_opt,gamma_hat_RM]  # sugg: [x_opt,gamma_hat_RM]
    x_opt_gamma = optimize.fmin(fun_gamma,x_guess_gamma)  # call the optimization solver
    beta_bar_opt_gamma = x_opt_gamma[0]
    S_bar_init_opt_gamma = x_opt_gamma[1]
    gamma_opt_gamma = x_opt_gamma[2]
    return (beta_bar_opt_gamma, S_bar_init_opt_gamma, gamma_opt_gamma)

plt.figure(figsize=(10,8))

# [[[ Start loop on train periods:
for period_cnt in range(0, len(train_t_start_vals)):

    # Extract train variables for period period_cnt:
    train_t_start = train_t_start_vals[period_cnt]
    train_t_end = train_t_end_vals[period_cnt]
    test_t_end = test_t_end_vals[period_cnt]
    tspan_train = [train_t_start,train_t_end]
    # The test data is defined to be all the data that occurs from train_t_end.
    # Replace test data by NaN in *_train variables.
    data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
    data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
    # ! Make sure to use only these *_train variables in the train phase.
    H_init = data_totinout_train[tspan_train[0],0]

    # Estimate beta_bar, S_bar_init, and gamma:
    beta_bar_opt_gamma, S_bar_init_opt_gamma, gamma_opt_gamma = estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL)

    # (Here we no longer plot the cost function because there are now 3 optimization variables.)

    # Compute statistics:
    stats_gamma = make_stats(beta_bar_opt_gamma, gamma_opt_gamma, S_bar_init_opt_gamma, H_init, tspan_train, dates, data_totinout)

    # Plot true and simulated H, and simulated S_bar:
    make_plots(beta_bar_opt_gamma,gamma_opt_gamma,S_bar_init_opt_gamma,H_init,tspan_train,dates,data_totinout)

# end loop on train periods
#plt.title("Optimized wrt beta_bar, S_bar_init, and gamma")
plt.show(block=False)


# ***********************************************************************************
# Optimization wrt beta_bar, S_bar_init, gamma, and H_init
# *******


def phi_gammaHinit(x,tspan_train,data_totinout_train,c_HEL):   # x := [beta_bar,S_bar_init,gamma,H_init]
    return phi_basic(x[0],x[2],x[1],x[3],tspan_train,data_totinout_train,c_HEL)


plt.figure(figsize=(10,8))
statss_gammaHinit = [None] * len(train_t_start_vals)  # storage for stats

# [[[ Start loop on train periods:
for period_cnt in range(0, len(train_t_start_vals)):

    # Extract train variables for period period_cnt:
    train_t_start = train_t_start_vals[period_cnt]
    train_t_end = train_t_end_vals[period_cnt]
    test_t_end = test_t_end_vals[period_cnt]
    tspan_train = [train_t_start,train_t_end]
    # The test data is defined to be all the data that occurs from train_t_end.
    # Replace test data by NaN in *_train variables.
    data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
    data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
    # ! Make sure to use only these *_train variables in the train phase.
    H_init = data_totinout_train[tspan_train[0],0]

    # Estimate beta_bar, S_bar_init, gamma, and H_init (no need to encapsulate it in a function):
    fun_gammaHinit = lambda x:phi_gammaHinit(x,tspan_train,data_totinout_train,c_HEL)  # function phi is given at the end of this script
    beta_bar_guess, S_bar_init_guess, gamma_guess = estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL)
    x_guess_gammaHinit = [beta_bar_guess, S_bar_init_guess,gamma_guess,H_init]
    x_opt_gammaHinit = optimize.fmin(fun_gammaHinit,x_guess_gammaHinit)  # call the optimization solver
    beta_bar_opt_gammaHinit = x_opt_gammaHinit[0]
    S_bar_init_opt_gammaHinit = x_opt_gammaHinit[1]
    gamma_opt_gammaHinit = x_opt_gammaHinit[2]
    H_init_opt_gammaHinit = x_opt_gammaHinit[3]

    # Compute statistics:
    stats_gammaHinit = make_stats(beta_bar_opt_gammaHinit, gamma_opt_gammaHinit, S_bar_init_opt_gammaHinit, H_init_opt_gammaHinit, tspan_train, dates, data_totinout)
    statss_gammaHinit[period_cnt] = stats_gammaHinit

    # Plot true and simulated H, and simulated S_bar:
    make_plots(beta_bar_opt_gammaHinit,gamma_opt_gammaHinit,S_bar_init_opt_gammaHinit,H_init_opt_gammaHinit,tspan_train,dates,data_totinout)
# end loop on train periods
#plt.title("Optimized wrt beta_bar, S_bar_init, gamma, and H_init")
plt.show(block=False)
fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_4D.pdf'
if save_figures: plt.savefig(fig_name_root + '_4D.pdf', format='pdf', bbox_inches='tight')

print("")

print("Tag:")
print(fig_name_root)
print("")

print("Stats with with beta_bar and S_bar_init optimized:")
print(statss )
print("")

print("Stats with with all estimands optimized:")
print(statss_gammaHinit)
print("")

print("MAPE_test with beta_bar and S_bar_init optimized (for last experiment, if several): ",stats['MAPE_test'])
print("")

print("MAPE_test with all estimands optimized (for last experiment, if several): ",stats_gammaHinit['MAPE_test'])
print("")

input("Press Enter to finish script execution")
