""" USER INSTRUCTIONS

Execute this file with python 3.
Tested with anaconda version 2019.10.

This file is the companion Python code of https://arxiv.org/abs/2007.10492.

The main parameters that affect the code behavior are mentioned in section "Switches" below. The parameters that the users are most likely to want to modify are marked with "!!".
"""


# ***********************************************************************************
# Changelog
# *******

# Code written by PA Absil and Ousmane Diao. There is NO WARRANTY of prediction accuracy.

# SHR_01PA.m - Started by PA on Sun 05 Jul 2020
# SHR_02PA.m - Started by PA on Sun 05 Jul 2020
#    Yields a remarkably good fit.
# SHR_03PA.m - Started by PA on Sun 05 Jul 2020
#    Version sent to Ousmane. Forked to Python version by Ousmane
# SHR_03PA_04OD.py
#    Version obtained from Ousmane on 2020-07-15
# SHR_03PA_05PA.py - Started by PA on Thu 16 Jul 2020
#    I plan to stay with Python from now on (instead of Matlab).
#    This version works well, both on the Linux command line and in Spyder. Figure 4 is particularly remarkable.
# SHR_03PA_06PA.py - Started by PA on Thu 16 Jul 2020
#    Clean up the code. Make it more compact. Use arrays of floats whenever possible. Define functions to avoid code repetition. From about 460 lines in SHR_03PA_04OD.py, we are down to about 360 lines (and the number of empty lines and comment lines has increased).
# SHR_03PA_07PA.py - Started by PA on Thu 16 Jul 2020
#     Reorder arguments of phi* functions more intuitively. Encapsulate various estimation tasks in functions estimate_* (as a preparation for loops on train periods). 
# SHR_03PA_08PA.py - Started by PA on Fri 17 Jul 2020
#     Loops on train periods.
# SHR_03PA_09PA.py - Started by PA on Fri 17 Jul 2020
#     Improve plots. Enable test_t_end.
# SHR_03PA_10PA.py - Started by PA on Sun 19 Jul 2020
#     Handle French data.
#     Plot E, L, EH. Set the bottom value of some plots to 0.
# SHR_15PA.py - Started by PA on Sun 19 Jul 2020
#     The Python version is now comparable to the Matlab version, hence this jump in the numbering.
# SHR_16PA.py - Started by PA on Mon 20 Jul 2020
#     Continue experimenting.
# SHR_17PA.py - Started by PA on Thu 06 Aug 2020
#     More experiments. Introduce show_figures. Introduce loop on cnt_state for BEL (state = province) and FRA (state = department). period_cnt -> cnt_period for notation consistency. Introduce nb_periods. Create stats_all to hold statistics. Fix the _test statistics to take test_t_end into account.
# SHR_18PA.py - Started by PA on Sat 08 Aug 2020
#     Remove MAPE() function as it was short and not much used. Print sorted statistics at the end. Print latex tables. Get rid of statss. Compute x_guess automatically. Add sMAPE and other statistics. Replace "state" by "district" in order to avoid confusion with the state of the dynamical system. Show initial guess and returned value on contour plot of obj fn. Remove old "In[<something>]:" lines. Reorganize sw_periods.

# ***********************************************************************************
# Imports
# *******

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#plt.rc('xtick', labelsize='x-small')
#plt.rc('ytick', labelsize='x-small')
#plt.rcParams['style'] = "sci"  # PATODO: try to set this globally
#plt.rcParams['scilimits'] = (0,0)

#from scipy.integrate import odeint
import math 
#from mpl_toolkits.mplot3d import Axes3D
#from math import hypot
from scipy import optimize
#from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt
#To change repertory
import os
#os.chdir ('C:\\Users\\odiao\\Desktop\\Model Covid19')
#os.getcwd ()
import copy
from datetime import datetime   # useful for date ranges in plots


# ***********************************************************************************
# Switches and other user choices - see also sw_periods and c_H, c_E, c_L below
# *******

sw_dataset = 'BEL'  # !! Default: 'BEL'. Currently 'BEL' and 'FRA' are available.
sw_districts = 'sum'  # !! Default: 'sum'. If 'sum', sums over all districts (i.e., provinces, departments...). If 'each', loop over all districts. sw_districts can also be the name of a district (for example, sw_districts = 'Brussels', or sw_districts = '75' for Paris).

show_totinout = 0  # Default: 0 # If 1, shows plots of total, in and out and check their discrepancy.
save_figures = 0  # If 1, some figures will be saved in pdf format.

show_figures = 1  # If 0, no figure shown. Will be set to 0 later on if nb_districts too large.
show_hist = 0
show_H = 1  # If 1, draw a plot of the evolution of H(t).
show_S_bar = 1
show_beta_bar = 1
show_gamma = 1

# ***********************************************************************************
# Load data Belgium
# *******

if sw_dataset == 'BEL':   
    # The data comes from https://epistat.sciensano.be/Data/COVID19BE_HOSP.csv.
    # This link was provided on 22 June 2020 by Alexey Medvedev on the "Re R0 estimation" channel of the O365G-covidata team on MS-Teams.
    # The link can be reached from https://epistat.wiv-isp.be/covid/
    # Some explanations can be found at https://epistat.sciensano.be/COVID19BE_codebook.pdf

    data_raw = pd.read_csv('Data/Belgium/COVID19BE_HOSP_2020-07-16.csv')
    #fields = ['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']

    if sw_districts == 'each':
        data_groupbydistrict = pd.DataFrame(data_raw.groupby("PROVINCE"))

# ***********************************************************************************
# Load data France
# *******

if sw_dataset == 'FRA':
    # The data comes from https://www.data.gouv.fr/en/datasets/donnees-hospitalieres-relatives-a-lepidemie-de-covid-19/, see donnees-hospitalieres-covid19-2020-07-10-19h00.csv

    data_raw = pd.read_csv('Data/France/donnees-hospitalieres-covid19-2020-07-17-19h00_corrected.csv')  # some dates were not in the correct format, hence the "corrected" version of the csv file
    data_raw = data_raw[data_raw.iloc[:,1]==0].reset_index(drop=True)  # Discard sex "1" and "2" (i.e., only keep sex "0" which is the sum of females and males) and reset the index in order to have a contiguous index in the DataFrame.

    if sw_districts == 'each':
        data_groupbydistrict = pd.DataFrame(data_raw.groupby("dep"))


# {{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{
# Start loop on districts
# *******
        
if sw_districts == 'sum':
    nb_districts = 1
elif sw_districts == 'each':
    nb_districts = len(data_groupbydistrict)
else:  # else nb_districts is the name of a district
    nb_districts = 1
    
if nb_districts > 2:
    show_figures = 0  # Force figures off if there are too many districts

for cnt_district in range(nb_districts):

    if sw_districts == 'sum':
        district_name = 'sum'
        district_names = np.array(['sum'])   # without np.array, we get an error in district_names[medians_argsort]
    elif sw_districts == 'each':
        district_name = data_groupbydistrict[0][cnt_district]
        district_names = data_groupbydistrict[0]
    else:
        district_name = sw_districts
        district_names = np.array([sw_districts])

    # ***********************************************************************************
    # Process data Belgium
    # *******

    if sw_dataset == 'BEL':

        if sw_districts == 'sum':
            data_raw_district = data_raw.groupby('DATE', as_index=False).sum()  # sum over provinces
        elif sw_districts == 'each':
            data_raw_district = data_groupbydistrict[1][cnt_district]  # extract province cnt_district
        else:   
            data_raw_district = data_raw[data_raw.iloc[:,1]==sw_districts].reset_index(drop=True)   # extract district with name sw_districts

        data = data_raw_district[['DATE', 'NR_REPORTING', 'TOTAL_IN','TOTAL_IN_ICU','TOTAL_IN_RESP','TOTAL_IN_ECMO','NEW_IN','NEW_OUT']]  # exclude some useless columns
            
        # Extract relevant data and recompute new_out:
        # Source: Some variable names taken from https://rpubs.com/JMBodart/Covid19-hosp-be
        data_length = np.size(data,0)
        data_num = data.iloc[:,1:].to_numpy(dtype=float)  # extract all rows and 2nd-last rows (recall that Python uses 0-based indexing) and turn it into a numpy array of flats. The "float" type is crucial due to the use of np.nan below. (Setting an integer to np.nan does not do what it is should do.)

        #dates = data['DATE'])
        dates_raw = copy.deepcopy(data['DATE'])
        dates_raw = dates_raw.reset_index(drop=True)  # otherwise the index is not contiguous when sw_districts = 'each'
        dates = [None] * data_length
        for i in range(0,data_length):
            dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

        col_total_in = 1
        col_new_in = 5
        col_new_out = 6
        total_in = data_num[:,col_total_in]
        new_in = data_num[:,col_new_in]
        new_out_raw = data_num[:,col_new_out] # there will be a non-raw due to the "Problem" mentioned below.
        new_delta = new_in - new_out_raw
        cum_new_delta = np.cumsum(new_delta)
        total_in_chg = np.hstack(([0],np.diff(total_in))) #difference between x[i+1]-x[i]
        # Problem: new_delta and total_in_chg are different, though they are sometimes close. 
        # Cum_new_delta does not go back to something close to zero, whereas it should. Hence I should not trust it.
        # I'm going to trust total_in and new_in. I deduce new_out_fixed by:
        new_out = new_in - total_in_chg   # fixed new_out
        data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns


        # Show Belgian data in figures:

        if show_figures & show_totinout:
            plt.figure(figsize=(10,8))
            plt.subplot(2,2,1)
            plt.plot(dates, total_in)
            plt.plot(dates,cum_new_delta)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.legend(("total_in","cum_new_delta"))
            #plt.ylim([0,1000])

            plt.subplot(2,2,2)
            plt.plot(dates,new_delta)
            plt.plot(dates,total_in_chg)
            plt.xlabel("Dates")
            plt.ylabel("Values")
            plt.legend(("new_delta","total_in_chg"))

            plt.subplot(2,2,3)
            plt.plot(dates,new_out_raw)
            plt.plot(dates,new_out)
            plt.legend(("new_out_raw","new_out"))

            plt.show(block=False)  # block=False does not block the execution of the script
        # end if show_totinout

    # ***********************************************************************************
    # Process data France
    # *******

    elif sw_dataset == 'FRA':  # if sw_datset is 'FRA'

        if sw_districts == 'sum':
            data_raw_district = data_raw.groupby('jour', as_index=False).sum()  # sum over identical dates
        elif sw_districts == 'each':
            data_raw_district = data_groupbydistrict[1][cnt_district]  # extract department cnt_district
        else:
            data_raw_district = data_raw[data_raw.iloc[:,0]==sw_districts].reset_index(drop=True)   # extract district with name sw_districts
            
        data = data_raw_district[['jour','hosp','rea','rad','dc']]  # exclude some useless columns

        # Extract relevant data and recompute new_in:
        data_length = np.size(data,0)
        data_num = data.iloc[:,1:].to_numpy(dtype=float)  # extract all rows and 2nd-last rows (recall that Python uses 0-based indexing) and turn it into a numpy array of flats. The "float" type is crucial due to the use of np.nan below. (Setting an integer to np.nan does not do what it is should do.)

        #dates = data['DATE'])
        dates_raw = copy.deepcopy(data['jour'])
        dates_raw = dates_raw.reset_index(drop=True)  # otherwise the index is not contiguous when sw_districts = 'each'
        dates = [None] * data_length
        for i in range(0,data_length):
            dates[i] = datetime.strptime(dates_raw[i],'%Y-%m-%d')

        col_total_in = 0
        col_new_in = np.nan   # no column for new_in in French data
        col_new_out = np.nan  # to get new_out we have to sum 'rad' and 'dc'
        total_in = data_num[:,col_total_in]
        new_out = np.hstack(([0],np.diff(data_num[:,2] + data_num[:,3])))
        total_in_chg = np.hstack(([0],np.diff(total_in)))
        new_in = new_out + total_in_chg
        data_totinout = np.c_[total_in,new_in,new_out]  # store total_in, new_in, and new_iout in an arraw with 3 columns

    # end if sw_dataset

    # ***********************************************************************************
    # Select train and test periods
    # *******

    sw_periods = '1.2.60'   # !!
    # '0.1': train over the whole data
    # '1.01': train period around the peak chosen "by hand" for BEL
    # '1.02': a few train periods around the peak chosen "by hand" for BEL
    # '1.1.60': put train period around peak WITH data leakage - do not use
    # '1.2.60': train period around the peak, selected automatically without data leakage
    # '2.1': train period around the end
    # '3.1': sliding train window, test until end
    # "3.1.60': sliding train window, test duration 60

    if sw_periods == '0.1':
        # One large train:  *keep*-with c_E=c_L=0, only show_H
        train_t_start_vals = np.array([1]);
        train_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);
        test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);

    if sw_periods == '1.01':
        # This one gives a MAPE_test of 7.9% for Belgium
        train_t_start_vals = np.array([18])
        train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
        test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int); 

    if sw_periods == '1.02':
        # A few small trains:  *keep*-only show_H show_S
        #train_t_start_vals = np.array([10,12,14,16,18,20,22])
        train_t_start_vals = np.arange(16,22,2)
        train_t_end_vals = (32) * np.ones(np.shape(train_t_start_vals),dtype=int)
        #train_t_end_vals = train_t_start_vals + 14
        test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int)

    if sw_periods == '1.1.60':  # put train period around peak WITH data leakage
        N = 7  # The window length of moving average will be 2N+1.
        total_in_MA = total_in * np.nan  # MA: moving average
        for t in range(0,len(total_in)):
            total_in_MA[t] = np.sum(total_in[max(0,t-N):min(t+N+1,len(total_in))]) / (min(t+N+1,len(total_in)) - max(0,t-N))
        t_max = np.argmax(total_in_MA)  # t_max is the position of the max of the MA
        train_t_start_vals = np.array([t_max-7])
        train_t_end_vals = train_t_start_vals + 15  # The train period is an interval of 15 days centered at the peak of total_in_MA
        test_t_end_vals = train_t_end_vals + 60
        # WARNING: In keeping with Python conventions, _end variables give the integer *before which* we stop.

        # if show_figures:   # plot total_in and total_in_MA
        #     plt.figure(figsize=(10,8))
        #     plt.plot(dates, total_in, "-", color='gray', label="Total_in")
        #     plt.plot(dates, total_in_MA, 'm--', label="total_in_MA")
        #     plt.xlabel("Dates")
        #     #plt.ylabel("Values")
        #     plt.legend()
        #     plt.show(block=False)

    if sw_periods == '1.2.60':  # put train period around peak while avoiding data leakage
        # *keep*
        N = 7  # The window length of moving average will be 2N+1.
        total_in_MA = total_in * np.nan  # MA: moving average
        # Find the first time where the latest peak of total_in_MA is N days behind:
        t = -1; t_max = -1
        while t_max != t-N or total_in_MA[t_max] == 0 or t-2*N < 0:
            t = t + 1
            total_in_MA[t] = np.sum(total_in[max(0,t-N):min(t+N+1,len(total_in))]) / (min(t+N+1,len(total_in)) - max(0,t-N))
            t_max = np.argmax(total_in_MA[:t+1])
        train_t_start_vals = np.array([t-2*N])
        train_t_end_vals = np.array([t+N+1])  # The train period stops the day before train_t_end_vals. Observe that the data from train_t_end_vals onward has not been used.
        test_t_end_vals = train_t_end_vals + 60

        
    # # One small train period around peak:
    # train_t_start_vals = np.array([18]);    # For Belgium, dates[17] is 2020-04-01
    # train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
    # test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int); 

    # # Two small train periods:
    # train_t_start_vals = np.array([10,60]);    # For Belgium, dates[17] is 2020-04-01
    # train_t_end_vals = train_t_start_vals + 14;  # + 14 for 14 days in train period
    # test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);

    # # Sliding train and test windows:
    # train_t_start_vals = np.arange(1,len(total_in)-28,7)  
    # train_t_end_vals = train_t_start_vals + 14
    # test_t_end_vals = train_t_end_vals + 14 

    if sw_periods == '2.1':
        # Train period around the end.
        train_t_start_vals = np.array([1+10*7]);
        #train_t_start_vals = np.arange(1+11*7,len(total_in)-28,7) 
        train_t_end_vals = train_t_start_vals + 14
        test_t_end_vals = (len(total_in)-0) * np.ones(np.shape(train_t_start_vals),dtype=int);

    if sw_periods == '3.1':
        # Sliding train window: *keep* - also for FRA
        train_t_start_vals = np.arange(1,len(total_in)-28,7) 
        train_t_end_vals = train_t_start_vals + 14
        test_t_end_vals = len(total_in) * np.ones(np.shape(train_t_start_vals),dtype=int)

    if sw_periods == '3.1.60':
        # Sliding train window:
        train_t_start_vals = np.arange(1,len(total_in)-14-60,7) 
        train_t_end_vals = train_t_start_vals + 14
        test_t_end_vals = train_t_end_vals + 60



    # ***********************************************************************************
    # Preparation
    # *******

    nb_periods = len(train_t_start_vals)  # number of periods, i.e., number of test-train experiments on the same data
    
    # Make sure that times are integers:
    train_t_start_vals = train_t_start_vals.astype(int)
    train_t_end_vals = train_t_end_vals.astype(int)
    test_t_end_vals = test_t_end_vals.astype(int)

    # Restrict test_t_end_vals from above by len(total_in):
    test_t_end_vals = np.minimum(test_t_end_vals,len(total_in))
    
    # Weights of the terms of the cost function:
    c_H, c_E, c_L = 1, 1, 1 # !! Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
    c_HEL = [c_H,c_E,c_L]

    # Part of file name of figures:
    name_root = os.path.splitext(os.path.basename(__file__))[0] + '_py_' + sw_dataset + sw_districts + '_1sttraintstart' + str(train_t_start_vals[0]) + '_1sttraintend' + str(train_t_end_vals[0]) + '_1sttesttend' + str(test_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L)
    fig_name_root = 'Figures/' + name_root


    # ***********************************************************************************
    # Show available data
    # *******

    if show_figures:
        plt.figure(figsize=(10,8))
        #plt.subplot(2,2,1)
        plt.plot(dates, total_in/np.max(total_in), "-", color='gray', label="Total_in norm\'d")
        plt.plot(dates, new_out/np.max(np.hstack((new_in,new_out))), 'm--', label="new_in norm\'d")
        plt.plot(dates, new_in/np.max(np.hstack((new_in,new_out))), 'b-.', label="new_out norm\'d")
        plt.plot(dates, new_in * total_in / np.max(new_in * total_in), ':', color='tab:purple', label="total_in * new_in norm\'d")
        plt.xlabel("Dates")
        plt.ylabel("Values")
        plt.legend()

        plt.show(block=False)



    #***********************************************************************************
    # Define gamma estimation function
    # *******
    # Model for gamma: new_out = gamma * total_in

    def estimate_gamma(tspan_train,data_totinout_train):

        train_t_start = tspan_train[0]
        train_t_end = tspan_train[1]
        total_in_train = data_totinout_train[:,0]
        new_out_train = data_totinout_train[:,2]

        # Estimator by ratio of means:
        #gamma_hat_RM = np.sum(new_out_train[0:train_t_end])/np.sum(total_in_train[0:train_t_end]) # This version uses all the non-test data.
        gamma_hat_RM = np.sum(new_out_train[train_t_start:train_t_end])/np.sum(total_in_train[train_t_start:train_t_end])  # This version uses only the "train" period.

        # Estimator by least squares:
        #gamma_hat_LS = total_in_train[0:train_t_end]\new_out_train[0:train_t_end]
        gamma_hat_LS = np.linalg.lstsq(np.c_[total_in_train[0:train_t_end]],new_out_train[0:train_t_end], rcond=None)[0]

        # Estimator by ratio of means on all data (test and train):  not legitimate
        #gamma_hat_all_RM = sum(new_out_train)/sum(total_in_train);

        # I observe that the RM and LS estimates are quite close. Let's keep:
        gamma = gamma_hat_RM
        #gamma = gamma_hat_all_RM;  % not legitimate

        return gamma
    # end def estimate_gamma

    #***********************************************************************************
    # Define function for successive (instead of joint) estimation of beta_bar and S_bar_init
    # *******

    def estimate_successive_betabar_Sbarinit(tspan_train,data_totinout_train):
        
        train_t_start = tspan_train[0]
        train_t_end = tspan_train[1]
        total_in_train = data_totinout_train[:,0]
        new_in_train = data_totinout_train[:,1]

        # Estimator by ratio of means:
        beta_bar_hat_RM = (total_in_train[train_t_end-1]-total_in_train[train_t_start]) / np.sum(total_in_train[train_t_start:train_t_end-1]**2) - (new_in_train[train_t_end-1]-new_in_train[train_t_start]) / np.sum(total_in_train[train_t_start:train_t_end-1]*new_in_train[train_t_start:train_t_end-1])  # This is based on equation (13) of https://arxiv.org/abs/2007.10492.

        beta_bar = beta_bar_hat_RM
        S_bar_init = new_in_train[train_t_start] / (beta_bar * total_in_train[train_t_start])

        # When the estimation is done in the decreasing phase, beta_bar_hat_RM can be negative. See SHR_18PA.py_save07 for an example. We remedy it as follows.
        if beta_bar < 0:
            beta_bar = -beta_bar
            S_bar_init = -S_bar_init 

        return beta_bar, S_bar_init

    
    # ***********************************************************************************
    # Define several functions: the SH simulation function; the general cost function on which the various parameter estimations will be based; a function that returns statistics; a function that draw plots of simulation results
    # *******

    # Define the simulation function of the SH model:
    def simu(beta_bar,gamma,S_bar_init,H_init,tspan):
        simu_t_start = tspan[0]
        simu_t_end = tspan[1]  # The time before which we stop, i.e., the last returned values are at t = simu_t_end - 1.
        S_bar = np.full(simu_t_end, np.nan)  # set storage Z = np.full(X.shape, np.nan)
        H = np.full(simu_t_end, np.nan)  # set storage
        E = np.full(simu_t_end, np.nan)  # set storage
        L = np.full(simu_t_end, np.nan)  # set storage
        S_bar[simu_t_start] = S_bar_init
        H[simu_t_start] = H_init

        for t in np.arange(simu_t_start,simu_t_end-1):
            S_bar[t+1] = S_bar[t] - beta_bar * S_bar[t] * H[t]
            H[t+1] = H[t] + beta_bar * S_bar[t] * H[t] - gamma * H[t]
            E[t+1] = beta_bar * S_bar[t] * H[t]
            L[t+1] = gamma * H[t]
        return (S_bar,H,E,L)
    # end def simu

    # Define the loss function in terms of all the possible decision variables, i.e., beta_bar,gamma,S_bar_init,H_init :
    def phi_basic(beta_bar,gamma,S_bar_init,H_init,tspan_train,data_totinout_train,c_HEL):
        # Extract variables from input:
        c_H, c_E, c_L = c_HEL  #coefficients of the terms of the cost function. Default: c_H = 1; c_E = 1; c_L = 1 (it gives a good MAPE_test)
        train_t_start, train_t_end = tspan_train
        _, H, E, L = simu(beta_bar,gamma,S_bar_init,H_init,tspan=tspan_train)  # "_" because S_bar is not involved in the cost
        # Compute the cost (discrepancy between observed and simulated):
        cost = c_H * (np.linalg.norm(H[train_t_start:train_t_end]-data_totinout_train[train_t_start:train_t_end,0]))**2 + c_E * (np.linalg.norm(E[train_t_start+1:train_t_end]-data_totinout_train[train_t_start+1:train_t_end,1]))**2 + c_L * (np.linalg.norm(L[train_t_start+1:train_t_end]-data_totinout_train[train_t_start+1:train_t_end,2]))**2
        return cost

    # Define function that gathers statistics in dict stats_all:
    def make_stats(stats_all,beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
        stats_keys = ['RMSE_train', 'RMSE_test', 'RMSE_test/RMSE_train', 'RRSE_train', 'RRSE_test', 'RRSE_test/RRSE_train', 'MAE_train', 'MAE_test', 'MAE_test/MAE_train', 'MASE', 'MASE_train', 'MASE_test', 'MASE_test/MASE_train', 'RelMAE_train', 'RelMAE_test', 'RelMAE_test/RelMAE_train', 'nMAE_train', 'nMAE_test', 'nMAE_test/nMAE_train', 'rnMAE_train', 'rnMAE_test', 'rnMAE_test/rnMAE_train', 'MAPE_train', 'MAPE_test', 'MAPE_test/MAPE_train', 'sMAPE_train', 'sMAPE_test', 'sMAPE_test/sMAPE_train']

        if not stats_all:  # If stats_all is still the empty dictionary, let's populate it.
            for key in stats_keys:
                stats_all[key] = np.full((nb_districts,nb_periods),np.nan)

        S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
        RMSE_train = np.linalg.norm(H[train_t_start:train_t_end] - total_in[train_t_start:train_t_end]) / math.sqrt(train_t_end-train_t_start)
        RMSE_test = np.linalg.norm(H[train_t_end:test_t_end] - total_in[train_t_end:test_t_end]) / math.sqrt(test_t_end-train_t_end)
        stats_all['RMSE_train'][cnt_district,cnt_period] = RMSE_train
        stats_all['RMSE_test'][cnt_district,cnt_period] = RMSE_test
        stats_all['RMSE_test/RMSE_train'][cnt_district,cnt_period] = stats_all['RMSE_test'][cnt_district,cnt_period] / stats_all['RMSE_train'][cnt_district,cnt_period]
        stats_all['RRSE_train'][cnt_district,cnt_period] = np.sqrt( np.sum((total_in[train_t_start:train_t_end] - H[train_t_start:train_t_end])**2) / np.sum((total_in[train_t_start:train_t_end] - np.mean(total_in[train_t_start:train_t_end]))**2) )
        stats_all['RRSE_test'][cnt_district,cnt_period] = np.sqrt( np.sum((total_in[train_t_end:test_t_end] - H[train_t_end:test_t_end])**2) / np.sum((total_in[train_t_end:test_t_end] - np.mean(total_in[train_t_end:test_t_end]))**2) )  # Root Relative Squared Error
        stats_all['RRSE_test/RRSE_train'][cnt_district,cnt_period] = stats_all['RRSE_test'][cnt_district,cnt_period] / stats_all['RRSE_train'][cnt_district,cnt_period]
        MAE_train = np.mean(np.abs(total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]))
        MAE_test = np.mean(np.abs(total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]))
        stats_all['MAE_train'][cnt_district,cnt_period] = MAE_train
        stats_all['MAE_test'][cnt_district,cnt_period] = MAE_test
        stats_all['MAE_test/MAE_train'][cnt_district,cnt_period] = stats_all['MAE_test'][cnt_district,cnt_period] / stats_all['MAE_train'][cnt_district,cnt_period]
        stats_all['MASE'][cnt_district,cnt_period] = np.mean(np.abs(total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end])) / np.mean(np.abs(total_in[train_t_start+1:train_t_end]-total_in[train_t_start:train_t_end-1]))  # Mean Absolute Scaled Error (dubious because we make multi-step forecasts, not one-step-ahead forecasts)
        stats_all['MASE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start+1:train_t_end]-total_in[train_t_start:train_t_end-1]))
        stats_all['MASE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end+1:test_t_end]-total_in[train_t_end:test_t_end-1]))  # MAE divided by MAE of the prescient naive one-step-ahead predictor (that predicts total_in[t] by total_in[t-1]). Since the decrease is slow, this can be interpreted as the MAE divided by the noise level. If it gets below 1, then the fit is visually excellent. This measure is strongly inspired from Hyndman & Koehler 2006 (https://doi.org/10.1016/j.ijforecast.2006.03.001).
        stats_all['MASE_test/MASE_train'][cnt_district,cnt_period] = stats_all['MASE_test'][cnt_district,cnt_period] / stats_all['MASE_train'][cnt_district,cnt_period]
        stats_all['RelMAE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start:train_t_end]-total_in[train_t_start-1]))
        stats_all['RelMAE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end:test_t_end]-total_in[train_t_end-1]))  # relative MAE, i.e., MAE of H divided by MAE of constant forecast total_in[train_t_end-1]
        stats_all['RelMAE_test/RelMAE_train'][cnt_district,cnt_period] = stats_all['RelMAE_test'][cnt_district,cnt_period] / stats_all['RelMAE_train'][cnt_district,cnt_period]
        stats_all['nMAE_train'][cnt_district,cnt_period] = MAE_train / np.mean(np.abs(total_in[train_t_start:train_t_end]))
        stats_all['nMAE_test'][cnt_district,cnt_period] = MAE_test / np.mean(np.abs(total_in[train_t_end:test_t_end]))  # normalized MAE, i.e., MAE of H divided by MAE of constant forecast 0
        stats_all['nMAE_test/nMAE_train'][cnt_district,cnt_period] = stats_all['nMAE_test'][cnt_district,cnt_period] / stats_all['nMAE_train'][cnt_district,cnt_period]
        stats_all['rnMAE_train'][cnt_district,cnt_period] = MAE_train / np.ptp(total_in[train_t_start:train_t_end])
        if train_t_end < test_t_end:  # if test is not empty (otherwise np.ptp below gives an error)
            stats_all['rnMAE_test'][cnt_district,cnt_period] = MAE_test / np.ptp(total_in[train_t_end:test_t_end])  # range-normalized MAE, i.e., MAE of H divided by the (diameter of the) range of the true values. (ptp means "peak to peak")
            stats_all['rnMAE_test/rnMAE_train'][cnt_district,cnt_period] = stats_all['rnMAE_test'][cnt_district,cnt_period] / stats_all['rnMAE_train'][cnt_district,cnt_period]
        else:
            stats_all['rnMAE_test'][cnt_district,cnt_period] = np.nan
            stats_all['rnMAE_test/rnMAE_train'][cnt_district,cnt_period] = np.nan
        stats_all['MAPE_train'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]) / total_in[train_t_start:train_t_end] ))
        stats_all['MAPE_test'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]) / total_in[train_t_end:test_t_end] ))
        stats_all['MAPE_test/MAPE_train'][cnt_district,cnt_period] = stats_all['MAPE_test'][cnt_district,cnt_period] / stats_all['MAPE_train'][cnt_district,cnt_period]
        stats_all['sMAPE_train'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_start:train_t_end]-H[train_t_start:train_t_end]) / ((total_in[train_t_start:train_t_end]+H[train_t_start:train_t_end])/2) ))
        stats_all['sMAPE_test'][cnt_district,cnt_period] = np.mean(np.abs( (total_in[train_t_end:test_t_end]-H[train_t_end:test_t_end]) / ((total_in[train_t_end:test_t_end]+H[train_t_end:test_t_end])/2) ))  # symmetric MAPE
        stats_all['sMAPE_test/sMAPE_train'][cnt_district,cnt_period] = stats_all['sMAPE_test'][cnt_district,cnt_period] / stats_all['sMAPE_train'][cnt_district,cnt_period]
        return
    # end def make_stats

    # Define function for plots:
    def make_plots(beta_bar,gamma,S_bar_init,H_init,tspan_train,dates,data_totinout):
        S_bar, H, E, L = simu(beta_bar, gamma, S_bar_init, H_init, tspan=[tspan_train[0],len(total_in)])
        nb_subplots = show_H + show_S_bar + show_beta_bar + show_gamma
        if nb_subplots == 4:
            nb_subplot_rows = 2
            nb_subplot_cols = 2
            plt.rc('xtick', labelsize='x-small')
            plt.rc('ytick', labelsize='x-small')
        else:
            nb_subplot_rows = 1
            nb_subplot_cols = nb_subplots 
        cnt_subplot = 0
        nb_xticks = 4
        dates_ticks = [None] * nb_xticks
        dates_ticks_ind = np.linspace(0,len(total_in)-1,nb_xticks,dtype=int)
        for i in range(0,nb_xticks):
            dates_ticks[i] = dates[dates_ticks_ind[i]]

        if show_H:
            cnt_subplot = cnt_subplot + 1
            plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)

            if cnt_period == 0:   # assign plot labels
                plt.plot(dates,total_in, "-", color='gray', label="Total_in", linewidth=1)
                plt.plot(dates[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--', label="H_train")
                plt.plot(dates[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.', label="H_pred")
                plt.legend()
            else:
                plt.plot(dates[train_t_start:train_t_end],H[train_t_start:train_t_end],'b--')
                plt.plot(dates[train_t_end-1:test_t_end],H[train_t_end-1:test_t_end],'r-.')
            plt.xticks(dates_ticks)
            plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
            if cnt_period == nb_periods-1:
                plt.ylim(bottom=0)

        if show_S_bar:
            cnt_subplot = cnt_subplot + 1
            plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
            if cnt_period == 0:   # assign plot labels
                plt.plot(dates[0:train_t_end],S_bar[0:train_t_end],'b--', label="S_bar_train")
                plt.plot(dates[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.', label="S_bar_pred")

                plt.legend()
            else:
                plt.plot(dates[train_t_start:train_t_end],S_bar[train_t_start:train_t_end],'b--')
                plt.plot(dates[train_t_end-1:test_t_end],S_bar[train_t_end-1:test_t_end],'r-.')
            plt.xticks(dates_ticks)
            plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
            if cnt_period == nb_periods-1:
                plt.ylim(bottom=0)

        if show_beta_bar:
            cnt_subplot = cnt_subplot + 1
            plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
            if cnt_period == 0:   # assign plot labels
                plt.plot(dates[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--', label="beta_bar_train")
                plt.plot(dates[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.', label="beta_bar_pred")
                plt.legend()
            else:
                plt.plot(dates[train_t_start:train_t_end],beta_bar*np.ones(train_t_end-train_t_start),'b--')
                plt.plot(dates[train_t_end-1:test_t_end],beta_bar*np.ones(test_t_end-train_t_end+1),'r-.')
            plt.xticks(dates_ticks)
            plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
            if cnt_period == nb_periods-1:
                plt.ylim(bottom=0)

        if show_gamma:
            cnt_subplot = cnt_subplot + 1
            plt.subplot(nb_subplot_rows,nb_subplot_cols,cnt_subplot)
            if cnt_period == 0:   # assign plot labels
                plt.plot(dates[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--', label="gamma_train")
                plt.plot(dates[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.', label="gamma_pred")
                plt.legend()
            else:
                plt.plot(dates[train_t_start:train_t_end],gamma*np.ones(train_t_end-train_t_start),'b--')
                plt.plot(dates[train_t_end-1:test_t_end],gamma*np.ones(test_t_end-train_t_end+1),'r-.')
            plt.xticks(dates_ticks)
            plt.ticklabel_format(axis="y", style="sci", scilimits=(0,0))
            if cnt_period == nb_periods-1:
                plt.ylim(bottom=0)
        return
    # end def make_plots

    # ***********************************************************************************
    # Optimization wrt beta_bar and S_bar_init
    # *******

    # Define the loss function where "x" contains the decision variables of interest in this section of the code, namely x := [beta_bar,S_bar_init]:
    def phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL):
        return phi_basic(x[0],gamma,x[1],H_init,tspan_train,data_totinout_train,c_HEL)

    # Extract train variables in order to do a first plot of the cost function:
    train_t_start = train_t_start_vals[0]
    train_t_end = train_t_end_vals[0]
    test_t_end = test_t_end_vals[0]
    tspan_train = [train_t_start,train_t_end]
    data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
    data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.

    # Define anonymous function for used in optimization solver:
    H_init = data_totinout_train[tspan_train[0],0]
    gamma = estimate_gamma(tspan_train,data_totinout_train)  # estimate gamma
    fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above

    # First plot of cost function, to get an idea of an init point for the optimization solver:
    if show_figures:
        beta_bar_vals = np.linspace(0,2e-5,100)  #beta_bar_vals = np.linspace(8e-6,12e-6,10)
        S_bar_init_vals = np.linspace(0,2e4,100)   #S_bar_init_vals = np.linspace(8e3,10e3,10)
        X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
        Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
        for i in np.arange(0,np.size(X,0)):
             for j in np.arange(0,np.size(X,1)):
                    #print(i,j)
                    #[X[i,j],Y[i,j]]
                    Z[i,j] = fun([X[i,j],Y[i,j]]) 
        plt.figure(figsize=(10,8))
        plt.contourf(X, Y, Z)
        plt.colorbar()
        plt.show(block=False)

    # Define function for the estimation of beta_bar and S_bar_init:
    def estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL):  # estimation method with beta_bar and S_bar_init as optimization variables
        # Estimate gamma:
        gamma = estimate_gamma(tspan_train,data_totinout_train)
        fun = lambda x:phi(x,gamma,H_init,tspan_train,data_totinout_train,c_HEL)  # function phi is defined above
        beta_bar_guess, S_bar_init_guess = estimate_successive_betabar_Sbarinit(tspan_train,data_totinout_train)
        x_guess = [beta_bar_guess, S_bar_init_guess]
        #x_guess = [1e-5,1e4]  # hard-coded guess. Sugg: [1e-5,1e4] 
        x_opt = optimize.fmin(fun,x_guess)  # call the optimization solver
        beta_bar_opt = x_opt[0]
        S_bar_init_opt = x_opt[1]
        fun_opt = fun([beta_bar_opt,S_bar_init_opt])  # value of the minimum, useful for plot
        return (beta_bar_opt, S_bar_init_opt, gamma, fun_opt, fun, x_guess)


    if show_figures:
        plt.figure(figsize=(10,8))

    # Storage for statistics as a dictionary of numpy arrays:
    # If we are dealing with the first district, then we have to create stats_all 
    if cnt_district == 0:   
        stats_all = {}   # Create dict stats_all. Using make_stats(s), it will become a dictionary of numpy arrays where we will record statistics for the various districts and periods.

    # [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
    # Start loop on train periods:
    for cnt_period in range(0, nb_periods):

        # Extract train variables for period cnt_period:
        train_t_start = train_t_start_vals[cnt_period]
        train_t_end = train_t_end_vals[cnt_period]
        test_t_end = test_t_end_vals[cnt_period]
        tspan_train = [train_t_start,train_t_end]
        # The test data is defined to be all the data that occurs from train_t_end.
        # Replace test data by NaN in *_train variables.
        data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
        data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
        # ! Make sure to use only these *_train variables in the train phase.
        H_init = data_totinout_train[tspan_train[0],0]

        # Estimate beta_bar and S_bar_init by optimizing the cost function:
        beta_bar_opt, S_bar_init_opt, gamma, fun_opt, fun, x_guess = estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL)

        # Compute statistics:
        make_stats(stats_all,beta_bar_opt, gamma, S_bar_init_opt, H_init, tspan_train, dates, data_totinout)

        # Plot true and simulated H, and simulated S_bar:
        if show_figures:
            make_plots(beta_bar_opt,gamma,S_bar_init_opt,H_init,tspan_train,dates,data_totinout)  
        #end if cnt_period

    # end loop on train periods
    # ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

    if show_figures:
        #plt.title("Optimized wrt beta_bar and S_bar_init")
        plt.show(block=False)
        if save_figures: plt.savefig(fig_name_root + '_2D.pdf', format='pdf', bbox_inches='tight')

    if show_figures:
        # Plot the cost function around the found minimizer:
        beta_bar_vals = np.linspace(0,beta_bar_opt*2,100)
        S_bar_init_vals = np.linspace(0,S_bar_init_opt*2,100)
        X,Y = np.meshgrid(beta_bar_vals,S_bar_init_vals)
        Z = np.full((np.size(X,0),np.size(X,1)), np.nan)
        for i in np.arange(0,np.size(X,0)):
             for j in np.arange(0,np.size(X,1)):
                Z[i,j] = math.log10(fun([X[i,j],Y[i,j]])-fun_opt*0.90)
        plt.figure(figsize=(10,8))
        plt.contourf(X, Y, Z)
        plt.colorbar()
        plt.plot(x_guess[0],x_guess[1],'ro')  # show initial guess provided to optimization solver
        plt.plot(beta_bar_opt,S_bar_init_opt,'r*')  # show point returned by optimization solver
        plt.title('log10(fun - fun\_opt*.90))')
        plt.ticklabel_format(style="sci", scilimits=(0,0))
        plt.show(block=False)
        fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_contour.pdf'
        if save_figures: plt.savefig(fig_name_root + '_contour.pdf', format='pdf', bbox_inches='tight')


    # ***********************************************************************************
    # Optimization wrt beta_bar, S_bar_init, and gamma
    # *******

    def phi_gamma(x,H_init,tspan_train,data_totinout_train,c_HEL):  #x := [beta_bar,S_bar_init,gamma]
        return phi_basic(x[0],x[2],x[1],H_init,tspan_train,data_totinout_train,c_HEL)

    # Define function for the estimation of beta_bar, S_bar_init, and gamma:
    def estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL):
        fun_gamma = lambda x:phi_gamma(x,H_init,tspan_train,data_totinout_train,c_HEL)
        beta_bar_guess, S_bar_init_guess, gamma_guess, _, _, _ = estimate_betabar_Sbarinit(H_init,tspan_train,data_totinout_train,c_HEL)
        x_guess_gamma = [beta_bar_guess,S_bar_init_guess,gamma_guess]       #[x_opt,gamma_hat_RM]  # sugg: [x_opt,gamma_hat_RM]
        x_opt_gamma = optimize.fmin(fun_gamma,x_guess_gamma)  # call the optimization solver
        beta_bar_opt_gamma = x_opt_gamma[0]
        S_bar_init_opt_gamma = x_opt_gamma[1]
        gamma_opt_gamma = x_opt_gamma[2]
        return (beta_bar_opt_gamma, S_bar_init_opt_gamma, gamma_opt_gamma)

    if show_figures:
        plt.figure(figsize=(10,8))

    # [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
    # Start loop on train periods:
    for cnt_period in range(0, nb_periods):

        # Extract train variables for period cnt_period:
        train_t_start = train_t_start_vals[cnt_period]
        train_t_end = train_t_end_vals[cnt_period]
        test_t_end = test_t_end_vals[cnt_period]
        tspan_train = [train_t_start,train_t_end]
        # The test data is defined to be all the data that occurs from train_t_end.
        # Replace test data by NaN in *_train variables.
        data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
        data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
        # ! Make sure to use only these *_train variables in the train phase.
        H_init = data_totinout_train[tspan_train[0],0]

        # Estimate beta_bar, S_bar_init, and gamma:
        beta_bar_opt_gamma, S_bar_init_opt_gamma, gamma_opt_gamma = estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL)

        # (Here we no longer plot the cost function because there are now 3 optimization variables.)

        # Compute statistics:
        #stats_gamma = make_stats(beta_bar_opt_gamma, gamma_opt_gamma, S_bar_init_opt_gamma, H_init, tspan_train, dates, data_totinout)

        # Plot true and simulated H, and simulated S_bar:
        if show_figures:
            make_plots(beta_bar_opt_gamma,gamma_opt_gamma,S_bar_init_opt_gamma,H_init,tspan_train,dates,data_totinout)

    # ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]
    # end loop on train periods

    if show_figures:
        #plt.title("Optimized wrt beta_bar, S_bar_init, and gamma")
        plt.show(block=False)


    # ***********************************************************************************
    # Optimization wrt beta_bar, S_bar_init, gamma, and H_init
    # *******


    def phi_gammaHinit(x,tspan_train,data_totinout_train,c_HEL):   # x := [beta_bar,S_bar_init,gamma,H_init]
        return phi_basic(x[0],x[2],x[1],x[3],tspan_train,data_totinout_train,c_HEL)


    if show_figures:
        plt.figure(figsize=(10,8))

    if cnt_district == 0:
        stats_all_gammaHinit = {}
    

    # [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[
    # Start loop on train periods:
    for cnt_period in range(0, nb_periods):

        # Extract train variables for period cnt_period:
        train_t_start = train_t_start_vals[cnt_period]
        train_t_end = train_t_end_vals[cnt_period]
        test_t_end = test_t_end_vals[cnt_period]
        tspan_train = [train_t_start,train_t_end]
        # The test data is defined to be all the data that occurs from train_t_end.
        # Replace test data by NaN in *_train variables.
        data_totinout_train = copy.deepcopy(data_totinout)  # in order to be able to "hide" entries in data_totinout_train without changing data_totinout
        data_totinout_train[train_t_end:,:] = np.nan  # Beware that data_totinout_train has to be floats.
        # ! Make sure to use only these *_train variables in the train phase.
        H_init = data_totinout_train[tspan_train[0],0]

        # Estimate beta_bar, S_bar_init, gamma, and H_init (no need to encapsulate it in a function):
        fun_gammaHinit = lambda x:phi_gammaHinit(x,tspan_train,data_totinout_train,c_HEL)  # function phi is given at the end of this script
        beta_bar_guess, S_bar_init_guess, gamma_guess = estimate_betabar_Sbarinit_gamma(H_init,tspan_train,data_totinout_train,c_HEL)
        x_guess_gammaHinit = [beta_bar_guess, S_bar_init_guess,gamma_guess,H_init]
        x_opt_gammaHinit = optimize.fmin(fun_gammaHinit,x_guess_gammaHinit)  # call the optimization solver
        beta_bar_opt_gammaHinit = x_opt_gammaHinit[0]
        S_bar_init_opt_gammaHinit = x_opt_gammaHinit[1]
        gamma_opt_gammaHinit = x_opt_gammaHinit[2]
        H_init_opt_gammaHinit = x_opt_gammaHinit[3]

        # Compute statistics:
        make_stats(stats_all_gammaHinit,beta_bar_opt_gammaHinit, gamma_opt_gammaHinit, S_bar_init_opt_gammaHinit, H_init_opt_gammaHinit, tspan_train, dates, data_totinout)

        # Plot true and simulated H, and simulated S_bar:
        if show_figures:
            make_plots(beta_bar_opt_gammaHinit,gamma_opt_gammaHinit,S_bar_init_opt_gammaHinit,H_init_opt_gammaHinit,tspan_train,dates,data_totinout)

    # end loop on train periods
    # ]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]

    if show_figures:
        #plt.title("Optimized wrt beta_bar, S_bar_init, gamma, and H_init")
        plt.show(block=False)
        fig_name = 'Figures/' + os.path.basename(__file__) + sw_dataset + '_traintstart' + str(train_t_start_vals[0]) + '_traintstop' + str(train_t_end_vals[0]) + '_c' + str(c_H) + str(c_E) + str(c_L) + '_4D.pdf'
        if save_figures: plt.savefig(fig_name_root + '_4D.pdf', format='pdf', bbox_inches='tight')

    # ***********************************************************************************
    # Display results for current cnt_district
    # *******

    print("***************************")

    print("District name:", district_name)

    print("MAPE_test with beta_bar and S_bar_init optimized (for last experiment, if several): ",stats_all['MAPE_test'][cnt_district,])
    print("")

    print("MAPE_test with all estimands optimized (for last experiment, if several): ",stats_all_gammaHinit['MAPE_test'][cnt_district,])
    print("")

# End loop on districts
# }}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

# ***********************************************************************************
# Print final results
# *******

print("******************** FORECAST ACCURACY MEASURES - district-by-period tables ********************")

print("********** With beta_bar and S_bar_init optimized **********")

print('MASE_test:')
print(stats_all['MASE_test'])

print('MAPE_test:')
print(stats_all['MAPE_test'])

print("********** With all estimands optimized **********")

print('MASE_test:')
print(stats_all_gammaHinit['MASE_test'])

print('MAPE_test:')
print(stats_all_gammaHinit['MAPE_test'])


print("******************** FORECAST ACCURACY MEASURES - sorted medians over periods ********************")

def print_sorted_medians(stats_key, stats_all):
    medians = np.median(stats_all[stats_key],axis=1)
    medians_argsort = np.argsort(medians)
    print(stats_key, "(medians over periods):\n", np.c_[medians[medians_argsort],district_names[medians_argsort]])
    print("")

print("********** With beta_bar and S_bar_init optimized **********")

print_sorted_medians('MASE_test',stats_all)
print_sorted_medians('MAPE_test',stats_all)
# print_sorted_medians('RelMAE_test',stats_all)
# print_sorted_medians('nMAE_test',stats_all)
# print_sorted_medians('rnMAE_test',stats_all)

print("********** With all estimands optimized **********")

print_sorted_medians('MASE_test',stats_all_gammaHinit)
print_sorted_medians('MAPE_test',stats_all_gammaHinit)
# print_sorted_medians('RelMAE_test',stats_all_gammaHinit)
# print_sorted_medians('nMAE_test',stats_all_gammaHinit)
# print_sorted_medians('rnMAE_test',stats_all_gammaHinit)


print("******************** FORECAST ACCURACY MEASURES - min, max over districts and periods ********************")

print("********** With beta_bar and S_bar_init optimized **********")

stats_all_keys = stats_all.keys()
for key in stats_all_keys:
    argmin = np.unravel_index(np.argmin(stats_all[key], axis=None), stats_all[key].shape)
    argmax = np.unravel_index(np.argmax(stats_all[key], axis=None), stats_all[key].shape)    
    print(key, "min over experiments: ", np.min(stats_all[key]), "obtained with district", district_names[argmin[0]], "and period", argmin[1])
    print(key, "max over experiments: ", np.max(stats_all[key]), "obtained with district", district_names[argmax[0]], "and period", argmax[1])


print("********** With all estimands optimized **********")

for key in stats_all_keys:
    argmin = np.unravel_index(np.argmin(stats_all_gammaHinit[key], axis=None), stats_all_gammaHinit[key].shape)
    argmax = np.unravel_index(np.argmax(stats_all_gammaHinit[key], axis=None), stats_all_gammaHinit[key].shape)    
    print(key, "min over experiments: ", np.min(stats_all_gammaHinit[key]), "obtained with district", district_names[argmin[0]], "and period", argmin[1])
    print(key, "max over experiments: ", np.max(stats_all_gammaHinit[key]), "obtained with district", district_names[argmax[0]], "and period", argmax[1])


print("******************** FORECAST ACCURACY MEASURES - latex table ********************")

# stats_keys_for_latex = ['RMSE_train', 'RMSE_test', 'MAE_train', 'MAE_test', 'MASE', 'MASE_train', 'MASE_test', 'RelMAE_test', 'nMAE_test', 'rnMAE_test',
#                         # 'MAPE_train', 'MAPE_test', # MAPE may give Inf and this causes trouble for statistics
#                         'sMAPE_train', 'sMAPE_test']

stats_keys_for_latex = ['RMSE_train', 'RMSE_test', 'RMSE_test/RMSE_train', 'RRSE_train', 'RRSE_test', 'RRSE_test/RRSE_train', 'MAE_train', 'MAE_test', 'MAE_test/MAE_train', 'MASE', 'MASE_train', 'MASE_test', 'MASE_test/MASE_train', 'RelMAE_train', 'RelMAE_test', 'RelMAE_test/RelMAE_train', 'nMAE_train', 'nMAE_test', 'nMAE_test/nMAE_train', 'rnMAE_train', 'rnMAE_test', 'rnMAE_test/rnMAE_train',
                        # 'MAPE_train', 'MAPE_test', 'MAPE_test/MAPE_train',  # MAPE may give Inf and this causes trouble for statistics
                        'sMAPE_train', 'sMAPE_test', 'sMAPE_test/sMAPE_train']

def make_latex_table(stats_all):
    print('\\begin{tabular}{c|ccccccc}')
    print('\\hline')
    print('Percentiles & min & $P_{10}$ & $P_{25}$ & $P_{50}$ & $P_{75}$ & $P_{90}$ & max \\\\ \\hline')
    for key in stats_keys_for_latex:
        print(key.replace('_','\_'), '&', "{:.2f}".format(np.min(stats_all[key])), '&', "{:.2f}".format(np.percentile(stats_all[key],10)), '&', "{:.2f}".format(np.percentile(stats_all[key],25)), '&', "{:.2f}".format(np.percentile(stats_all[key],50)), '&', "{:.2f}".format(np.percentile(stats_all[key],75)), '&', "{:.2f}".format(np.percentile(stats_all[key],90)), '&', "{:.2f}".format(np.max(stats_all[key])), '\\\\')
        if '/' in key:
            print('\\hline')
    print('\\end{tabular}')

print("********** With beta_bar and S_bar_init optimized **********")
make_latex_table(stats_all)
print("********** With all estimands optimized **********")
make_latex_table(stats_all_gammaHinit)

print("")
print("Command to record a snapshot that reproduces the results:")
print("zip -r ", name_root, ".zip README.txt ", os.path.splitext(os.path.basename(__file__))[0], ".py Data/", sep = '')
#print("zip -r ", name_root, ".zip README.txt ", ".py Data/", sep = '')
print("Think about including in the zip archive the figure of interest, if any.")
print("")


# ***********************************************************************************
# Show histograms
# *******

def make_hist(stats_key):
    plt.figure(figsize=(10,8))
    MAPE_test_hist = np.mean(stats_all[stats_key], axis=1)
    MAPE_test_hist = MAPE_test_hist[MAPE_test_hist<np.inf]  # Remove inf entries if any
    plt.hist(MAPE_test_hist, bins=10**np.linspace(np.log10(np.min(MAPE_test_hist)),np.log10(np.max(MAPE_test_hist)),10))
    plt.xscale('log')
    plt.xlabel(stats_key)
    plt.show(block=False)

if show_hist and nb_districts > 1:   # no point showing a histogram if there is only one district
    make_hist('MAPE_test')
    make_hist('RelMAE_test')

input("Press Enter to finish script execution")
