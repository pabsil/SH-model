donnees-hospitalieres-covid19-2020-07-10-19h00.csv           metadonnees-donnees-hospitalieres-covid19.csv
donnees-hospitalieres-nouveaux-covid19-2020-07-10-19h00.csv  metadonnees-hospit-incid.csv

obtained from https://www.data.gouv.fr/en/datasets/donnees-hospitalieres-relatives-a-lepidemie-de-covid-19/

