To reproduce the results of https://sites.uclouvain.be/absil/2020.05, start MATLAB and run SHR_12PA.
Tested with MATLAB R2019a.
- PA Absil, 2020-07-12


